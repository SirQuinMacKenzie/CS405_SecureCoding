// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // Include standard exception types

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw any standard exception
    throw std::runtime_error("Standard exception occurred in do_even_more_custom_application_logic");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap call in an exception handler
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw a custom exception
    throw std::logic_error("Logical error in custom application logic");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Handle division by zero with a standard exception
    if (den == 0)
    {
        throw std::domain_error("Division by zero error");
    }
    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    // Capture only the exception thrown by divide()
    try
    {
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& e)
    {
        std::cerr << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const std::logic_error& e)
    {
        std::cerr << "Logic error caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "std::exception caught in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Unknown exception caught in main!" << std::endl;
    }

    std::cout << "Program execution continues..." << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
